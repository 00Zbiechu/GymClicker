# GymClicker

Aplikacja typu clicker o tematyce związanej z kulturystyką, która polega na wykonywaniu ćwiczeń. W aplikacji zaimplementowany został licznik zdobytych pkt oraz booster podnoszący możliwości zawodnika. Enjoy!
